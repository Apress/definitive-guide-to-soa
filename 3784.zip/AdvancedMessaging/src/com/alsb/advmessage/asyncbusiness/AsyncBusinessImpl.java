package com.alsb.advmessage.asyncbusiness;

import java.util.Date;
import javax.jws.WebService;
import weblogic.jws.*;

/**
 * AsyncBusinessImpl class implements web service endpoint interface
 * AsyncBusiness
 */

@WebService(serviceName = "AsyncBusiness", targetNamespace = "http://www.alsb.com/AsyncBusiness/", endpointInterface = "com.alsb.advmessage.asyncbusiness.AsyncBusiness")
// Use the following JMS queue to get buffered JMS messages
@BufferQueue(name ="alsb.WebServiceQueue")
@WLHttpTransport(contextPath = "advmessage", serviceUri = "AsyncBusiness", portName = "AsyncBusinessSOAP")
public class AsyncBusinessImpl implements AsyncBusiness {

	private static long fiveMinutes = 300000;

	private static long thirtySeconds = 30000;

	private static long timeDelay = thirtySeconds;

	public AsyncBusinessImpl() {
	}

	@MessageBuffer(retryCount = 5, retryDelay = "10 seconds")
	public void submitAsyncOrder(com.alsb.order.Order submitOrder)
	{
		Date now = new Date();
		System.out.println("Starting to process the async order id "
				+ submitOrder.getId() + " at " + now.toLocaleString());
		try {
			Thread.sleep(timeDelay);
		} catch (InterruptedException ex) {
			ex.printStackTrace();
		} finally {
			now = new Date();
			System.out.println("Completed processing the async order id "
					+ submitOrder.getId()+ " at " + now.toLocaleString());
		}
	}
}
