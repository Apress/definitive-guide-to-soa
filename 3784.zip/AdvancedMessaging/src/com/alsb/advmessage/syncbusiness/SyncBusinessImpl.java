package com.alsb.advmessage.syncbusiness;

import javax.jws.WebService;
import weblogic.jws.*;

/**
 * SyncBusinessImpl class implements web service endpoint interface SyncBusiness */

@WebService(
  serviceName="SyncBusiness",
  targetNamespace="http://www.alsb.com/SyncBusiness/",
  endpointInterface="com.alsb.advmessage.syncbusiness.SyncBusiness")
@WLHttpTransport(contextPath="advmessage",serviceUri="SyncBusiness",portName="SyncBusinessSOAP")
public class SyncBusinessImpl implements SyncBusiness {
 
	private static long thirtySeconds = 30000;
    private static long timeDelay = thirtySeconds;
    private static int orderID = 100;

  public SyncBusinessImpl() {
  
  }

  public com.alsb.order.Order submitOrder(com.alsb.order.Order submitOrder) {
	  // Assign an order ID to the order
	  submitOrder.setId(orderID++);
	  System.out.println("Starting to process the SYNC order id " +
				submitOrder.getId());
		com.alsb.order.Order result = new com.alsb.order.Order();
		result.setFirstName(submitOrder.getFirstName());
		result.setId(submitOrder.getId());
		result.setLastName(submitOrder.getLastName());
		result.setLineItem(submitOrder.getLineItem());

		if (result.getId() % 2 == 0) {
			// Even numbered order succeed
			result.setOrderStatus(com.alsb.order.OrderStatus.completed);
		} else {
			// Odd numbered orders fail
			result.setOrderStatus(com.alsb.order.OrderStatus.error);
		}

		try {
			Thread.sleep(timeDelay);
		} catch (InterruptedException ex) {
			ex.printStackTrace();
		} finally {
			System.out.println("Completed processing the SYNC order id "
					+ submitOrder.getId());
		}
		return result;         
  }
}  