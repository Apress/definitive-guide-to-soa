/**
 * Generated from schema type t=LineItem@http://www.alsb.com/order/
 */
package com.alsb.order;

public class LineItem implements java.io.Serializable {

  private com.alsb.order.Product product;

  public com.alsb.order.Product getProduct() {
    return this.product;
  }

  public void setProduct(com.alsb.order.Product product) {
    this.product = product;
  }

  private int quantity;

  public int getQuantity() {
    return this.quantity;
  }

  public void setQuantity(int quantity) {
    this.quantity = quantity;
  }

}
