/**
 * Generated from schema type t=Product@http://www.alsb.com/order/
 */
package com.alsb.order;

public class Product implements java.io.Serializable {

  private java.lang.Integer creditNeeded;

  public java.lang.Integer getCreditNeeded() {
    return this.creditNeeded;
  }

  public void setCreditNeeded(java.lang.Integer creditNeeded) {
    this.creditNeeded = creditNeeded;
  }

  private java.lang.String name;

  public java.lang.String getName() {
    return this.name;
  }

  public void setName(java.lang.String name) {
    this.name = name;
  }

}
