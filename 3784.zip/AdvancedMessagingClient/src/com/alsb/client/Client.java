package com.alsb.client;

import java.util.Calendar;
import com.alsb.order.*;
import com.alsb.order.holders.*;

public class Client {

	/**
	 * A simple client that will make multiple calls to the Async_Proxy service
	 * to show the overall speed of invoking asynchronous web services.
	 */
	public static void main(String[] args) {
		String url = "http://localhost:7001/esb/Async_Proxy?WSDL";
		int numOrdersToSubmit = 30;
		try {
			AsyncProxy_Service service = new AsyncProxy_Service_Impl(url);
			AsyncProxy_PortType port = service.getAsyncProxySOAP();
			Calendar startTime = Calendar.getInstance();
			
			// Send a series of orders to see how fast we can submit them
			for(int i = 0; i < numOrdersToSubmit; i++) {
				com.alsb.order.Order order = new Order();
				order.setFirstName("Order " + i);
				OrderHolder orderHolder = new OrderHolder(order);
				port.submitAsyncOrder(orderHolder);
			}
			Calendar endTime = Calendar.getInstance();
			long time = endTime.getTimeInMillis() - startTime.getTimeInMillis();
			System.out.println(" Submitting " + numOrdersToSubmit + " orders took " + time + " ms");
		} catch(Exception ex) {
			ex.printStackTrace();
		}

	}

}
