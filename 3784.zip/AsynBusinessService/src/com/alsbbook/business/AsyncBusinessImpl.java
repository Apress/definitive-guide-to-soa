package com.alsbbook.business;

import javax.jws.Oneway;
import javax.jws.WebMethod;
import javax.jws.WebResult;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.Oneway;
import javax.jws.soap.SOAPBinding;
import weblogic.jws.WLHttpTransport;
import weblogic.jws.MessageBuffer;
import weblogic.jws.BufferQueue;
import com.alsbbook.business.OrderResultValue;
import com.alsbbook.business.OrderValue;

@WebService(name="AsyncBusinessPortType", serviceName="AsyncBusinessService", targetNamespace="http://example.org")
// Use the following JMS queue to get buffered JMS messages
@BufferQueue(name="alsb.WebServiceQueue")
// Using a SOAP binding that is ENCODED will cause the deployment to fail. Must use LITERAL instead.
@SOAPBinding(style=SOAPBinding.Style.DOCUMENT, use=SOAPBinding.Use.LITERAL, parameterStyle=SOAPBinding.ParameterStyle.WRAPPED)
@WLHttpTransport(contextPath="async", serviceUri="AsyncBusinessService", portName="AsyncBusinessServicePort")

/**
 * This file implements the AsyncBusinessService web service. It has
 * one main operation: submitOrder.
 * 
 * The web service is defined as "document-literal", which means the 
 * SOAP message have a single part referencing an XML Schema element
 * that defines the entire body.
 * 
 * @author Jeff Davies
 */
public class AsyncBusinessImpl {
	private static long fiveMinutes = 300000;
	private static long thirtySeconds = 30000;
	private static long timeDelay = thirtySeconds;
	
	@WebMethod()
	@Oneway()
	@MessageBuffer(retryCount=10, retryDelay="10 seconds")
	/**
	 * This is an asynchronous web service. All it does is sleep for 5 minutes
	 * to help demonstrate that the call was indeed asynchronous
	 * @param order The order to be processed.
	 * @return void
	 */
	public void submitAsyncOrder(@WebParam(name="Order") OrderValue order) {
		System.out.println("Starting to process the async order id " + order.getOrderId());
		try {
			Thread.sleep(timeDelay);
		} catch(InterruptedException ex) {
			ex.printStackTrace();
		} finally {
			System.out.println("Completed processing the async order id " + order.getOrderId());
		}
	}
}
