package com.alsbbook.business;

import java.util.Calendar;

public class OrderValue {
	private int orderId;
	private Calendar orderDate;
	private String firstName;
	private String lastName;
	
	public OrderValue() {
		orderId = 0;
		orderDate = Calendar.getInstance();
	}
	public Calendar getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Calendar orderDate) {
		this.orderDate = orderDate;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
}
