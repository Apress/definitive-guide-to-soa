/**
 * Generated from schema type t=OrderValue@java:com.alsbbook.business
 */
package com.alsbbook.business;

public class OrderValue implements java.io.Serializable {

  private java.util.Calendar orderDate;

  public java.util.Calendar getOrderDate() {
    return this.orderDate;
  }

  public void setOrderDate(java.util.Calendar orderDate) {
    this.orderDate = orderDate;
  }

  private int orderId;

  public int getOrderId() {
    return this.orderId;
  }

  public void setOrderId(int orderId) {
    this.orderId = orderId;
  }

  private java.lang.String firstName;

  public java.lang.String getFirstName() {
    return this.firstName;
  }

  public void setFirstName(java.lang.String firstName) {
    this.firstName = firstName;
  }

  private java.lang.String lastName;

  public java.lang.String getLastName() {
    return this.lastName;
  }

  public void setLastName(java.lang.String lastName) {
    this.lastName = lastName;
  }

}
