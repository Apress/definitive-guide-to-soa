package com.alsbbook.business;

import javax.xml.rpc.ServiceException;
import java.rmi.RemoteException;
import java.util.Calendar;
import java.util.Date;
import javax.xml.soap.*;

public class Client {
	static int orderId = 1;
	static int numCalls = 5;
	
	public static void main(String[] args) {
		OrderValue order = null;
		AsyncBusinessService service = null;
		AsyncBusinessPortType port = null;
		String url = "http://localhost:7001/async/AsyncBusinessService?WSDL";
		
		// Connect to the web service
		System.out.println("Connecting to the web service at " + url);
		Date connectStart = new Date();
		try {
			service = new AsyncBusinessService_Impl(url);
			port = service.getAsyncBusinessServicePort();
		} catch(ServiceException ex) {
			System.out.println("ServiceException!");
			ex.printStackTrace();
		} 
		Date connectEnd = new Date();
		// Do the asynchronous work
		for(int i = 0; i < numCalls; i++) {
			try {
				order = generateOrder();
				port.submitAsyncOrder(order);	
				//System.out.println("--- order submitted.");
			} catch(RemoteException ex) {
				System.out.println("RemoteException!");
				ex.printStackTrace();
			}
			if(order != null) {
				//System.out.println("Order " + order.getOrderId() + " was submitted for asynchronous processing.");
			} else {
				System.out.println("ERROR: Either order or result was null!");
			}
		}
		Date asyncWorkDone = new Date();
		
		// Print the summary of the timings
		System.out.println("\n\nAsynchronous Timing Results");
		System.out.println("---------------------------");
		System.out.println("Time spent connecting to the service: " + (connectEnd.getTime() - connectStart.getTime()) + " ms.");
		System.out.println("Total time spent for " + numCalls + " service calls: " + (asyncWorkDone.getTime() - connectEnd.getTime()) + " ms.");
		System.out.println("Average time per service call: " + ((asyncWorkDone.getTime() - connectEnd.getTime())/numCalls) + " ms.");
	}
	
	private static OrderValue generateOrder() {
		OrderValue order = new OrderValue();
		order.setOrderId(orderId++);
		order.setOrderDate(Calendar.getInstance() );
		return order;
	}
}
