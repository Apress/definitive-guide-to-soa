package com.alsbbook.business;

import javax.xml.rpc.ServiceException;
import javax.xml.rpc.handler.soap.SOAPMessageContext;

import java.io.StringReader;
import java.rmi.RemoteException;
import java.util.Calendar;
import java.util.Date;
import javax.xml.soap.*;
import javax.xml.transform.stream.StreamSource;

import weblogic.wsee.context.WebServiceContext;

public class Client {
	static int orderId = 1;
	static int numCalls = 10;
	
	public static void main(String[] args) {
		OrderValue order = null;
		AsyncRRClientService service = null;
		AsyncRRClientPortType port = null;
		String url = "http://localhost:7001/asyncRR/AsyncRRClientService?WSDL";
		
		// Connect to the web service
		System.out.println("Connecting to the web service at " + url);
		Date connectStart = new Date();
		try {
			service = new AsyncRRClientService_Impl(url);
			port = service.getAsyncRRClientServicePort();
			
			// Jump through some hoops to create an attachment
			WebServiceContext ctx = service.context();
			SOAPMessageContext soapCtx = ctx.getLastMessageContext();
			SOAPMessage soapMsg = soapCtx.getMessage();
			AttachmentPart ap = soapMsg.createAttachmentPart();
			
			// Define a MIME attachment
			String xml = "<START><A>Hello World</A></START>";
			StringReader rdr = new StringReader(xml);
			StreamSource source = new StreamSource(rdr); 
			soapMsg.createAttachmentPart(source, "text/xml");
			soapMsg.addAttachmentPart(ap);
		} catch(ServiceException ex) {
			System.out.println("ServiceException!");
			ex.printStackTrace();
		} 
		Date connectEnd = new Date();
		// Do the asynchronous work
		for(int i = 0; i < numCalls; i++) {
			try {
				order = generateOrder();
				//System.out.println("Submitting async order...");
				port.submitOrderAsync(order);
				//System.out.println("--- order submitted.");
			} catch(RemoteException ex) {
				System.out.println("RemoteException!");
				ex.printStackTrace();
			}
			if(order != null) {
				//System.out.println("Order " + order.getOrderId() + " was submitted for asynchronous processing.");
			} else {
				System.out.println("ERROR: Either order or result was null!");
			}
		}
		Date asyncWorkDone = new Date();
		
		// Print the summary of the timings
		System.out.println("\n\nAsynchronous Timing Results");
		System.out.println("---------------------------");
		System.out.println("Time spent connecting to the service: " + (connectEnd.getTime() - connectStart.getTime()) + " ms.");
		System.out.println("Total time spent for " + numCalls + " service calls: " + (asyncWorkDone.getTime() - connectEnd.getTime()) + " ms.");
		System.out.println("Average time per service call: " + ((asyncWorkDone.getTime() - connectEnd.getTime())/numCalls) + " ms.");
	}
	
	private static OrderValue generateOrder() {
		OrderValue order = new OrderValue();
		order.setOrderId(orderId++);
		order.setOrderDate(Calendar.getInstance() );
		return order;
	}
}
