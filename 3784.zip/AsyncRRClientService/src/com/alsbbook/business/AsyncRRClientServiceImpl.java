package com.alsbbook.business;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.soap.SOAPBinding;
import weblogic.jws.ServiceClient;
import weblogic.jws.WLHttpTransport;
import weblogic.jws.AsyncResponse;
import weblogic.jws.AsyncFailure;
import weblogic.wsee.async.AsyncPreCallContext;
import weblogic.wsee.async.AsyncPostCallContext;
import weblogic.wsee.async.AsyncCallContextFactory;
import com.alsbbook.business.OrderValue;
import com.alsbbook.business.OrderResultValue;
import java.rmi.RemoteException;

@WebService(name="AsyncRRClientPortType", serviceName="AsyncRRClientService", targetNamespace="http://example.org")
//Using a SOAP binding that is ENCODED will cause the deployment to fail. Must use LITERAL instead.
@SOAPBinding(style=SOAPBinding.Style.DOCUMENT, use=SOAPBinding.Use.LITERAL, parameterStyle=SOAPBinding.ParameterStyle.WRAPPED)
@WLHttpTransport(contextPath="asyncRR", serviceUri="AsyncRRClientService", portName="AsyncRRClientServicePort")

/**
* This file implements the AsyncRRClientService web service. It has
* one main operation: submitOrder.
* 
* The web service is defined as "document-literal", which means the 
* SOAP message have a single part referencing an XML Schema element
* that defines the entire body.
* 
* @author Jeff Davies
*/
public class AsyncRRClientServiceImpl {
	// The portName here needs to match the portName attribute of the WLHttpTransport attribute 
	// on the synchronous service.
	@ServiceClient(wsdlLocation="http://localhost:7001/sync/SyncBusinessService?WSDL", 
			serviceName="SyncBusinessService", portName="SyncBusinessService")
			
	private SyncBusinessPortType port;
	
	@WebMethod
	public void submitOrderAsync(@WebParam() OrderValue order) {
		AsyncPreCallContext apc = AsyncCallContextFactory.getAsyncPreCallContext();
		apc.setProperty("order", order);
		
		try {
			port.submitOrderAsync(apc, order);
			System.out.println("Just called the submitOrderAsyc() method from the AsyncRRClientService.");
		} catch(RemoteException ex) {
			ex.printStackTrace();
		}
		return;
	}
	
	@AsyncResponse(target="port", operation="submitOrder")
	public void onSubmitOrderAsyncResponse(AsyncPostCallContext apc, OrderResultValue result) {
		System.out.println("Got an order result. Status is: " + result.getOrderStatus() + " for order " + result.getOrderId());
	}
	
	@AsyncFailure(target="port", operation="submitOrder")
	public void onSubmitOrderAsyncFailure(AsyncPostCallContext apc, Throwable ex) {
		ex.printStackTrace();
	}
}
