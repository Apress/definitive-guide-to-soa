package com.alsb.business;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

import com.bea.wli.sb.context.BinaryContentType;

import weblogic.jws.WLHttpTransport;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

@WebService(name="BinaryPort", targetNamespace="http://www.alsb.com")
@SOAPBinding(style=SOAPBinding.Style.DOCUMENT, use=SOAPBinding.Use.LITERAL, 
		parameterStyle=SOAPBinding.ParameterStyle.WRAPPED)
@WLHttpTransport(contextPath="binary", serviceUri="BinaryService")
/**
 * A simple web service that takes an array of bytes, representing a file,
 * and writes them out to a file.
 */
public class BinaryService {

	@WebMethod()
	/**
	 * @param args
	 */
	public void acceptFile(String fileContents) {
		// Write the file out to a temporary file
		System.out.println("BinaryService: Received a file " + fileContents);
		try {
			File file = File.createTempFile("abc", null);
			FileOutputStream fos = new FileOutputStream(file);
			//fos.write(fileContents);
			fos.close();
		} catch(IOException ex) {
			ex.printStackTrace();
		}
	}

}
