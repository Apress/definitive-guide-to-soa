package com.alsb.goodbye.proxy;

import java.rmi.RemoteException;

public class Client {
	/**
	 * @param args
	 */
	public static void main(String[] args) throws javax.xml.rpc.ServiceException, RemoteException {
		// TODO Auto-generated method stub
		String url = "http://localhost:7001/esb/Goodbye_Service?WSDL";
        HelloWorldService service = new HelloWorldService_Impl(url);
        HelloWorldPort port = service.getHelloWorldPortSoapPort();
        
        String[] names = {"John", "Mary", "Samuel", "Barbara" };
        
        for(int i = 0; i < names.length; i++) {
	        System.out.println("getGreeting request: " + names[i]);
	        System.out.println("getGreeting results: " + port.getGreeting(names[i]));
        }
	}
}
