package com.alsb.business.hello;

import javax.jws.*;
import weblogic.jws.WLHttpTransport;
import weblogic.jws.WSDL;
import javax.jws.soap.SOAPBinding;

@WebService(name="HelloWorld", serviceName = "HelloWorldService", targetNamespace = "http://www.alsb.com")
@WLHttpTransport(serviceUri = "HelloWorldService", portName = "HelloWorldSoapPort")
@WSDL(exposed=true)
@SOAPBinding()
public class HelloWorld {

	@WebMethod
	public String getGreeting(String name) {
        return("Hello " + name + " from the business service!!!");
    }
}