package com.alsb.client;

public class HelloWorldClient {
	
	/**
	 * A simple Java POJO that calls the HelloWorldService.
	 */
	public static void main(String[] args) {
		String url = "http://localhost:7001/business/hello/HelloWorldService?WSDL";
		try {
			HelloWorldService service = new HelloWorldService_Impl(url);
			HelloWorld port = service.getHelloWorldSoapPort();
			String greeting = port.getGreeting("Bob");
			System.out.println(greeting);
		} catch(Exception ex) {
			ex.printStackTrace();
		}
	}
}
