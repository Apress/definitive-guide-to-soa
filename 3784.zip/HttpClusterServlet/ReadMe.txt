To build the HttpClusterServlet.war file, build the project and then export 
the project using the HttpClusterServlet web module. Save the destination as
HttpClusterServlet.war.