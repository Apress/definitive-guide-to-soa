package com.covad.alsb;

import javax.xml.rpc.ServiceException;
import java.rmi.RemoteException;
import java.util.Calendar;
import java.util.Date;

public class Client {
	static int orderId = 1;
	static int numCalls = 20;
	
	public static void main(String[] args) {
		OrderValue order = null;
		OrderResultValue result = null;
		RichMessageService service = null;
		RichMessagePortType port = null;
		String url = "http://localhost:7001/chapter4/RichMessageService?WSDL";
		
		// Connect to the web service
		System.out.println("Connecting to the web service at " + url);
		Date connectStart = new Date();
		try {
			service = new RichMessageService_Impl(url);
			port = service.getRichMessageServicePort();
		} catch(ServiceException ex) {
			System.out.println("ServiceException!");
			ex.printStackTrace();
			//ex.printStackTrace();
		} 
		Date connectEnd = new Date();
		
		// Do the synchronous work
		for(int i = 0; i < numCalls; i++) {
			try {
				order = generateOrder();
				result = port.submitOrder(order);	
			} catch(RemoteException ex) {
				System.out.println("RemoteException!");
				ex.printStackTrace();
			}
			if(order != null && result != null) {
				//System.out.println("Order " + order.getOrderId() + " has a result of: " + result.getOrderStatus());
			} else {
				System.out.println("ERROR: Either order or result was null!");
			}
		}
		Date workDone = new Date();
		
		// Print the summary of the timings
		System.out.println("Synchronous Timing Results");
		System.out.println("--------------------------");
		System.out.println("Connecting to the service: " + (connectEnd.getTime() - connectStart.getTime()) + " ms.");
		System.out.println("Total time spent for " + numCalls + " service calls: " + (workDone.getTime() - connectEnd.getTime()) + " ms.");
		System.out.println("Average time per service call: " + ((workDone.getTime() - connectEnd.getTime())/numCalls) + " ms.");
		
		// Do the asynchronous work
		for(int i = 0; i < numCalls; i++) {
			try {
				order = generateOrder();
				//System.out.println("Submitting async order...");
				port.submitAsyncOrder(order);	
				//System.out.println("--- order submitted.");
			} catch(RemoteException ex) {
				System.out.println("RemoteException!");
				ex.printStackTrace();
			}
			if(order != null) {
				//System.out.println("Order " + order.getOrderId() + " was submitted for asynchronous processing.");
			} else {
				System.out.println("ERROR: Either order or result was null!");
			}
		}
		Date asyncWorkDone = new Date();
		
		// Print the summary of the timings
		System.out.println("\n\nAsynchronous Timing Results");
		System.out.println("---------------------------");
		System.out.println("Total time spent for " + numCalls + " service calls: " + (asyncWorkDone.getTime() - workDone.getTime()) + " ms.");
		System.out.println("Average time per service call: " + ((asyncWorkDone.getTime() - workDone.getTime())/numCalls) + " ms.");
	}
	
	private static OrderValue generateOrder() {
		//System.out.println("Generating a new order...");
		OrderValue order = new OrderValue();
		order.setOrderId(orderId++);
		order.setOrderDate(Calendar.getInstance() );
		//System.out.println("   order generated. ID = " + order.getOrderId());
		return order;
	}

}
