/**
 * MessageFlowProxyServiceSoapBindingSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.alsb.www;

public class MessageFlowProxyServiceSoapBindingSkeleton implements com.alsb.www.MessageFlowProxyPort, org.apache.axis.wsdl.Skeleton {
    private com.alsb.www.MessageFlowProxyPort impl;
    private static java.util.Map _myOperations = new java.util.Hashtable();
    private static java.util.Collection _myOperationsList = new java.util.ArrayList();

    /**
    * Returns List of OperationDesc objects with this name
    */
    public static java.util.List getOperationDescByName(java.lang.String methodName) {
        return (java.util.List)_myOperations.get(methodName);
    }

    /**
    * Returns Collection of OperationDescs
    */
    public static java.util.Collection getOperationDescs() {
        return _myOperationsList;
    }

    static {
        org.apache.axis.description.OperationDesc _oper;
        org.apache.axis.description.FaultDesc _fault;
        org.apache.axis.description.ParameterDesc [] _params;
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.alsb.com/", "CustomerName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.alsb.com/", ">CustomerName"), com.alsb.www.CustomerName.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getProducts", _params, new javax.xml.namespace.QName("http://www.alsb.com/", "ArrayOfProduct"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://www.alsb.com/order/", "ProductList"));
        _oper.setElementQName(new javax.xml.namespace.QName("", "getProducts"));
        _oper.setSoapAction("getProducts");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getProducts") == null) {
            _myOperations.put("getProducts", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getProducts")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.alsb.com/", "Order"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.alsb.com/order/", "Order"), com.alsb.www.order.Order.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("submitOrder", _params, null);
        _oper.setElementQName(new javax.xml.namespace.QName("", "submitOrder"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("submitOrder") == null) {
            _myOperations.put("submitOrder", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("submitOrder")).add(_oper);
    }

    public MessageFlowProxyServiceSoapBindingSkeleton() {
        this.impl = new com.alsb.www.MessageFlowProxyServiceSoapBindingImpl();
    }

    public MessageFlowProxyServiceSoapBindingSkeleton(com.alsb.www.MessageFlowProxyPort impl) {
        this.impl = impl;
    }
    public com.alsb.www.order.Product[] getProducts(com.alsb.www.CustomerName customerName) throws java.rmi.RemoteException
    {
        com.alsb.www.order.Product[] ret = impl.getProducts(customerName);
        return ret;
    }

    public void submitOrder(com.alsb.www.order.Order order) throws java.rmi.RemoteException
    {
        impl.submitOrder(order);
    }

}
