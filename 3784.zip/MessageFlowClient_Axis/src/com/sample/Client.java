package com.sample;

import com.alsb.www.CustomerName;
import com.alsb.www.MessageFlowProxyPort;
import com.alsb.www.MessageFlowProxyServiceLocator;
import java.rmi.RemoteException;
import javax.xml.rpc.ServiceException;
import org.apache.axis.AxisFault;

public class Client {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			MessageFlowProxyServiceLocator service = new MessageFlowProxyServiceLocator();
			MessageFlowProxyPort port = service.getMessageFlowProxySoapPort();
									
			CustomerName name = new CustomerName();
			name.setFirstName("John");
			name.setLastName("Smith");
							
			com.alsb.www.order.Product[] products = port.getProducts(name);
			
			if(products != null) {
				System.out.println("Products appear valid");
				for(int x = 0; x < products.length; x++) {
					System.out.println("Product: " + products[x].getName() + " requires credit of " + products[x].getCreditNeeded());
				}
			} else {
				System.out.println("Product[] is null!");
			}
		}
		catch (ServiceException svce) {
			svce.printStackTrace();
		}
		catch (AxisFault e) {
            e.printStackTrace();
	    } catch (RemoteException e) {
	            e.printStackTrace();
	    }
	}
}
