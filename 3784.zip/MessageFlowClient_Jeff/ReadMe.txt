Assumption is that the zip is extracted to C:\Temp\MessageFlowSample if you want to use the same project file etc.

See C:\Temp\MessageFlowSample\MessageFlowClient\JavaBuildPathSettings.png for jars, I only added the user library WebLogic WebServiceClient manually (from your book, page 14 chapter 2). I skipped the jars to minimize the file size.

I exported the WSDL from my local ALSB installation to the directory C:\Temp\MessageFlowSample\MessageFlowClient.

I created proxy classes via the BEA Workshop wizard "Web Services/Web Service Client" (show all wizards checked).

The package com.sample contains the code I entered to call the actual web service which is the "Message Workflow" web service in ALSB. It also contains the MessageFlow web service that I published from Workshop in the Chapter 6 exercise. Everything is locally on the same machine. When I run the proxy service in the ALSB test tool within ALSB, I get a valid product list in the response.

When I call the Client class in com.sample, I recieve the following error.

Sep 6, 2007 4:36:18 PM org.apache.axis.client.Call invoke
SEVERE: Exception:
org.xml.sax.SAXException: Invalid element in com.alsb.www.order.ProductList - productList
	at org.apache.axis.encoding.ser.BeanDeserializer.onStartChild(BeanDeserializer.java:258)
	at org.apache.axis.encoding.DeserializationContext.startElement(DeserializationContext.java:1035)
	at org.apache.axis.message.SAX2EventRecorder.replay(SAX2EventRecorder.java:165)
	at org.apache.axis.message.MessageElement.publishToHandler(MessageElement.java:1141)
	at org.apache.axis.message.RPCElement.deserialize(RPCElement.java:236)
	at org.apache.axis.message.RPCElement.getParams(RPCElement.java:384)
	at org.apache.axis.client.Call.invoke(Call.java:2448)
	at org.apache.axis.client.Call.invoke(Call.java:2347)
	at org.apache.axis.client.Call.invoke(Call.java:1804)
	at com.alsb.www.MessageFlowProxyServiceSoapBindingStub.getProducts(MessageFlowProxyServiceSoapBindingStub.java:194)
	at com.sample.Client.main(Client.java:28)

The above was the sample that is included with BEA Workshop and from my understanding Axis1 soap framework is used for the actual call.
