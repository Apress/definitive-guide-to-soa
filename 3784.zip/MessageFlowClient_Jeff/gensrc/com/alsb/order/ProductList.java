/**
 * Generated from schema type t=ProductList@http://www.alsb.com/order/
 */
package com.alsb.order;

public class ProductList implements java.io.Serializable {

  private com.alsb.order.Product[] product;

  public com.alsb.order.Product[] getProduct() {
    return this.product;
  }

  public void setProduct(com.alsb.order.Product[] product) {
    this.product = product;
  }

}
