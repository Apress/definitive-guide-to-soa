package com.sample;

import com.alsb.*;
import com.sample.*;
import com.alsb.order.Product;
import com.alsb.order.ProductList;
import java.rmi.RemoteException;
import javax.xml.soap.*;
import javax.xml.rpc.*;

public class Client {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String url = "http://localhost:8080/sbresource?PROXY/Message+Flow/getProducts";
		url = "http://localhost:7001/GetProductsProxy?WSDL";
		try {
			// For use when connecting to ports
			MessageFlowProxyService service = new MessageFlowProxyService_Impl(url);
			MessageFlowProxyPort port = service.getMessageFlowProxySoapPort();
			
			// For use when connecting to bindings
			//MessageFlowProxyServiceSoapBindingQSService service = new MessageFlowProxyServiceSoapBindingQSService_Impl(url); 
			//MessageFlowProxyPort port = service.getMessageFlowProxyServiceSoapBindingQSPort();
			CustomerName custName = new CustomerName();
			custName.setFirstName("John");
			custName.setLastName("Doe");
			
			ProductList prodList = port.getProducts(custName);
			
			if(prodList == null) {
				System.out.println("Product list is null!");
			} else {
				System.out.println("prodList as string = " + prodList.toString());
				Product[] products = prodList.getProduct();
				if(products == null) {
					System.out.println("Product array is null!");
				} else {
					for(int i = 0; i < products.length; i++) {
						Product prod = products[i];
						System.out.println("John Smith can purchase: " + prod.getName());
					}
				}
			}
			
		} catch(ServiceException ex) {
			ex.printStackTrace();
		}
			catch(RemoteException ex) {
			ex.printStackTrace();
		}
	}
}
