Summary
========
When calling a web service I get the following error message: javax.xml.rpc.soap.SOAPFaultException: Failed to get operation name from the incoming request

Environment Info
=============
I'm using ALSB with 2 patches: CR238756_200_v1.zip and CR235270_900.jar. However, I believe this is a WLS 9 issue and not soomething specific to AquaLogic. You will need ANT 1.6 installed (earlier versions are probably OK) and I'm using the JDK 1.5.0_03 that shipped with the ALSB 2.0 release

Steps to Reproduce
===============
1) Install the web service via the WL Console. The service file can be found at: Messaging\bin\com\covad\alsb\RichMessagePortImpl.war in the attached ZIP file. Verify that the WAR file was deployed and is active (in the WL Console) before proceeding

2) Uncompress the ZIP file I have attached into a new directory, preserving the directory structure

3) Edit the setEnv.cmd file in the project root directory to match your environment

4) Open a system console (aka the DOS box if you are an old timer) and navigate the project directory

5) Execute the command: "ant build.wsclient" This will build our cllient. This should build without incident

6) Execute the command: "ant run.wsclient" This should result in the same error message that I specified in the Summary of this document.

Notes
=====
The full error text will point out that on line 37 of the RichMessagePortStub.java file, the operation name "submitOrder" does not exist. Yet if you check the WSDL of the deployed web service by pointing your browser to http://localhost:7001/chapter4/RichMessageService?WSDL you will see that an operation with that same name is defined (close to the bottom of the WSDL). I am unsure if this is a BEA error or an error on my part. Unfortunatley, I do not know how to debug this problem so I am asking for your help in resolving this issue. Please feel free to contact me at any time. 

Thanks in advance!

Jeff Davies
Covad Communications
408-952-6437
jdavies@covad.com