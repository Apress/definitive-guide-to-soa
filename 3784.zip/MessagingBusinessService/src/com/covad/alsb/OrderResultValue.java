package com.covad.alsb;

import java.util.Calendar;

public class OrderResultValue {
	public static int STATUS_PROCESSING = 1;
	public static int STATUS_COMPLETE = 2;
	public static int STATUS_ERROR = 3;
	
	private int orderId;
	private Calendar orderDate;
	private int orderStatus;
	
	public OrderResultValue() {
	}

	public Calendar getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Calendar orderDate) {
		this.orderDate = orderDate;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(int orderStatus) {
		this.orderStatus = orderStatus;
	}
	
	public void setOrderValue(OrderValue order) {
		this.orderId = order.getOrderId();
		this.orderDate = order.getOrderDate();
	}
}
