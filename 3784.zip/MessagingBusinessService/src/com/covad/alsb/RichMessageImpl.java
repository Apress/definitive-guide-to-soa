package com.covad.alsb;

import javax.jws.Oneway;
import javax.jws.WebMethod;
import javax.jws.WebResult;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.Oneway;
import javax.jws.soap.SOAPBinding;
import weblogic.jws.WLHttpTransport;
import weblogic.jws.MessageBuffer;
import weblogic.jws.BufferQueue;
import com.covad.alsb.OrderResultValue;
import com.covad.alsb.OrderValue;

@WebService(name="RichMessagePortType", serviceName="RichMessageService", targetNamespace="http://example.org")
// Use the following JMS queue to get buffered JMS messages
@BufferQueue(name="alsb.WebServiceQueue")
// Using a SOAP binding that is ENCODED will cause the deployment to fail. Must use LITERAL instead.
@SOAPBinding(style=SOAPBinding.Style.DOCUMENT, use=SOAPBinding.Use.LITERAL, parameterStyle=SOAPBinding.ParameterStyle.WRAPPED)
@WLHttpTransport(contextPath="chapter4", serviceUri="RichMessageService", portName="RichMessageServicePort")

/**
 * This file implement the RichMessageService web service. It has
 * one main operation: submitOrder.
 * 
 * The web service is defined as "document-literal", which means the 
 * SOAP message have a single part referencing an XML Schema element
 * that defines the entire body.
 * 
 * @author Jeff Davies
 */
public class RichMessageImpl {
	private static long fiveMinutes = 300000;
	private static long thirtySeconds = 30000;
	
	@WebMethod()
	@WebResult(name="OrderResultValue")
	/**
	 * This is a synchronous operation. If the given order ID is an odd number, the
	 * result of the order will be <code>OrderResultValue.STATUS_ERROR</code>, otherwise
	 * the result will be <code>OrderResultValue.STATUS_COMPLETE</code> This method also 
	 * shows how to use user-defined datatypes within a web service.
	 * @param order The order to be processed.
	 * @return The results of the order processing.
	 */
    public OrderResultValue submitOrder(@WebParam(name="Order") OrderValue order)
    {
		System.out.println("Starting to process the SYNC order id " + order.getOrderId());
		OrderResultValue result = new OrderResultValue();
		result.setOrderValue(order);
		if(result.getOrderId() % 2 == 0) {
			// Even numbered order succeed
			result.setOrderStatus(OrderResultValue.STATUS_COMPLETE);
		} else {
			// Odd numbered orders fail
			result.setOrderStatus(OrderResultValue.STATUS_ERROR);
		}
		System.out.println("Completed processing the SYNC order id " + order.getOrderId());
        return result;
    }
	
	@WebMethod()
	@Oneway()
	@MessageBuffer(retryCount=10, retryDelay="10 seconds")
	/**
	 * This is an asynchronous web service. All it does is sleep for 5 minutes
	 * to help demonstrate that the call was indeed asynchronous
	 * @param order The order to be processed.
	 * @return void
	 */
	public void submitAsyncOrder(@WebParam(name="Order") OrderValue order) {
		System.out.println("Starting to process the async order id " + order.getOrderId());
		try {
			Thread.sleep(thirtySeconds);
		} catch(InterruptedException ex) {
			ex.printStackTrace();
		} finally {
			System.out.println("Completed processing the async order id " + order.getOrderId());
		}
	}
}
