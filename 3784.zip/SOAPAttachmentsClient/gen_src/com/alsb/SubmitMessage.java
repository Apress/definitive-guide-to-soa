/**
 * Generated from schema type t|e=submitMessage|d=submitMessage@http://www.alsb.com
 */
package com.alsb;

public class SubmitMessage implements java.io.Serializable {

  private com.alsb.DummyMessage msg;

  public com.alsb.DummyMessage getMsg() {
    return this.msg;
  }

  public void setMsg(com.alsb.DummyMessage msg) {
    this.msg = msg;
  }

}
