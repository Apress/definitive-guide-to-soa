package com.alsb.saaj;

import javax.xml.rpc.ServiceException;
import javax.xml.rpc.handler.soap.SOAPMessageContext;
import java.io.StringReader;
import java.rmi.RemoteException;
import javax.xml.soap.*;
import javax.xml.transform.stream.StreamSource;
import com.alsb.*;
import com.alsb.holders.*;
import weblogic.wsee.context.WebServiceContext;

public class SAAJClient {
	public static void main(String[] args) {
		SOAPAttachmentService service = null;
		SOAPAttachment port = null;
		String url = "http://localhost:7001/saaj/SOAPAttachmentService?WSDL";
		
		// Connect to the web service
		System.out.println("Connecting to the web service at " + url);
		try {
			service = new SOAPAttachmentService_Impl(url);
			port = service.getSOAPAttachmentSoapPort();
			
			// Jump through some hoops to create an attachment
			System.out.println("About to get the web context");
			//WebServiceContext ctx = service.context();
			WebServiceContext ctx = service.joinContext();
			//WebServiceContext ctx = WebServiceContext.currentContext();
			
			SOAPFactory soapFactory = SOAPFactory.newInstance();
			SOAPElement elem = soapFactory.createElement("Foo");

			MessageFactory msgFactory = MessageFactory.newInstance();
			System.out.println("About to get the SOAP message context");
			SOAPMessageContext soapCtx = ctx.getLastMessageContext();
			SOAPMessage soapMsg = msgFactory.createMessage();
			AttachmentPart ap = soapMsg.createAttachmentPart();
			
			// Define a MIME attachment
			String xml = "<START><A>Hello World</A></START>";
			StringReader rdr = new StringReader(xml);
			StreamSource source = new StreamSource(rdr); 
			soapMsg.createAttachmentPart(source, "text/xml");
			soapMsg.addAttachmentPart(ap);
			
			// Call the service
			DummyMessage dm = new DummyMessage();
			dm.setId(123);
			dm.setName("Foobar");
			SubmitMessage msg = new SubmitMessage();
			msg.setMsg(dm);
			SubmitMessageHolder smh = new SubmitMessageHolder(msg);
			port.submitMessage(smh);
		} catch(ServiceException ex) {
			System.out.println("ServiceException!");
			ex.printStackTrace();
		} catch(RemoteException ex) {
			ex.printStackTrace();
		} catch(Exception ex) {
			System.out.println("Poopies!");
			ex.printStackTrace();
		}
	}
}