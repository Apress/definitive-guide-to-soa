package com.alsb.soapwithattachments;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.jws.WebService;
import weblogic.jws.*;

/**
 * SOAPwithAttachmentPortImpl class implements web service endpoint interface SOAPwithAttachmentPort */

@WebService(
  serviceName="SOAPwithAttachment",
  targetNamespace="http://www.alsb.com/SOAPwithAttachment/",
  endpointInterface="com.alsb.soapwithattachments.SOAPwithAttachmentPort")
@WLHttpTransport(contextPath="/",serviceUri="SOAPwithAttachment",portName="SOAPwithAttachmentSOAP")
public class SOAPwithAttachmentPortImpl implements SOAPwithAttachmentPort {
 
  public SOAPwithAttachmentPortImpl() {
  
  }

  public java.lang.String submitAttachment(java.lang.String fileName,javax.activation.DataHandler file) {
	  String contentType = file.getContentType();
	  System.out.println("Received file with a content type of: " + contentType);
	  String outputFileName = "c:\\" + fileName;
	  
	  try {
		  InputStream is = file.getInputStream();
		  FileOutputStream fos = new FileOutputStream(outputFileName);
		  // Read the input stream 1K at a time
		  byte[] buffer = new byte[1024];
		  while(is.available() > 0) {
			  System.out.println("Available bytes to read: " + is.available());
			  int numRead = is.read(buffer);
			  fos.write(buffer, 0, numRead);
		  }
		  fos.close();
		  is.close();
	  } catch(IOException ex) {
		  ex.printStackTrace();
	  }
     return outputFileName;         
  }
}  