package com.alsb.business;

import javax.ejb.MessageDrivenBean;
import javax.ejb.MessageDrivenContext;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.BytesMessage;
import weblogic.ejbgen.Constants;
import weblogic.ejbgen.MessageDriven;
import java.io.FileOutputStream;
import java.io.File;
import java.io.IOException;


@MessageDriven(maxBeansInFreePool = "200",
        destinationType = "javax.jms.Topic",
        initialBeansInFreePool = "20",
        transTimeoutSeconds = "0",
        defaultTransaction = MessageDriven.DefaultTransaction.REQUIRED,
        durable = Constants.Bool.FALSE,
        ejbName = "binaryMDB",
        destinationJndiName = "binaryFileTopic")
public class BinaryMDB implements MessageDrivenBean, MessageListener  {
	public final static long serialVersionUID = 1L;
	private static final boolean VERBOSE = true;
	private MessageDrivenContext m_context;

	/**
	 * Sets the session context.
	 *
	 * @param ctx  MessageDrivenContext Context for session
	 */
	public void setMessageDrivenContext(MessageDrivenContext ctx) {
		m_context = ctx;
	}

	/**
	 * Retrieve the BytesMessage and save that data as a file
	 */
	public void onMessage(Message msg) {
		BytesMessage bm = (BytesMessage) msg;
		try {
			long length = bm.getBodyLength();
			byte[] binaryData = new byte[(int)length];
			int numRead = bm.readBytes(binaryData);
			// Create a temporary file on the local file system.
			File outputFile = File.createTempFile("mdb_", "xxx");
			log("Created the file: " + outputFile.getAbsolutePath() + 
					" with a file size of " + numRead + " bytes");
			FileOutputStream fos = new FileOutputStream(outputFile);
			fos.write(binaryData);
			fos.close();
		} catch(IOException ex) {
			ex.printStackTrace();
		} catch(JMSException ex) {
			System.err.println("An exception occurred: "+ex.getMessage());
		}
	}

	/**
	 * This method is required by the EJB Specification,
	 * but is not used by this example.
	 */
	public void ejbCreate() { }

	/**
	 * This method is required by the EJB Specification,
	 * but is not used by this example.
	 */
	public void ejbRemove() { }

	private void log(String s) {
		if (VERBOSE) System.out.println(s);
	}

}
