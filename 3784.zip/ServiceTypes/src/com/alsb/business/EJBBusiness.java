package com.alsb.business;

import javax.ejb.*;
import weblogic.ejbgen.*;
import weblogic.ejb.GenericSessionBean;

/**
 * This is a stateless session bean that is invoked from 
 * the AquaLogic service bus.
 * 
 * @author jedavies
 *
 */
@FileGeneration(remoteClass = Constants.Bool.TRUE,
        localHome = Constants.Bool.FALSE,
        remoteHome = Constants.Bool.TRUE,
        remoteClassName = "EJBBusinessRemote",
        remoteHomeName = "EJBBusinessHome",
        localClass = Constants.Bool.FALSE)
@JarSettings(ejbClientJar = "ejbBusiness_client.jar")
@JndiName(remote = "EJBBusinessHome")
@Session(maxBeansInFreePool = "100",
        initialBeansInFreePool = "1",
        transTimeoutSeconds = "0",
        type = Session.SessionType.STATELESS,
        defaultTransaction = Constants.TransactionAttribute.REQUIRED,
        ejbName = "EJBBusiness",
        enableCallByReference = Constants.Bool.TRUE)
public class EJBBusiness extends GenericSessionBean {
	public final static long serialVersionUID = 1L;
	
	/**
	   * This method corresponds to the create method in the home interface
	   * "EJBBusinessHome.java".
	   * The parameter sets of the two methods are identical. When the client calls
	   * <code>EJBBusinessHome.create()</code>, the container allocates an instance of
	   * the EJBean and calls <code>ejbCreate()</code>.
	   *
	   * @throws javax.ejb.CreateException if there is
	   *         a communications or systems failure
	   * @see com.alsb.business.EJBBusinessRemote
	   */
	  public void ejbCreate() throws CreateException {
	  }

	  /**
	   * Calculate the tax on the given amount
	   *
	   * @param taxableAmount  The amount to which we apply the tax
	   * @return The amount of tax that is due.
	   */
	  @RemoteMethod()
	  public double calculateTax(double taxableAmount) {
		  double taxRate = 0.08;
		  return taxableAmount * taxRate;
	  }
}
