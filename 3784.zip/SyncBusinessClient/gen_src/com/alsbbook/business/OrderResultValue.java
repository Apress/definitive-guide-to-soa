/**
 * Generated from schema type t=OrderResultValue@java:com.alsbbook.business
 */
package com.alsbbook.business;

public class OrderResultValue {

  private java.util.Calendar orderDate;

  public java.util.Calendar getOrderDate() {
    return this.orderDate;
  }

  public void setOrderDate(java.util.Calendar orderDate) {
    this.orderDate = orderDate;
  }

  private int orderId;

  public int getOrderId() {
    return this.orderId;
  }

  public void setOrderId(int orderId) {
    this.orderId = orderId;
  }

  private int orderStatus;

  public int getOrderStatus() {
    return this.orderStatus;
  }

  public void setOrderStatus(int orderStatus) {
    this.orderStatus = orderStatus;
  }

}
