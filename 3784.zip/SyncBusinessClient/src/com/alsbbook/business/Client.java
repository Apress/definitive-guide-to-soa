package com.alsbbook.business;

import javax.xml.rpc.ServiceException;
import java.rmi.RemoteException;
import java.util.Calendar;
import java.util.Date;
import com.alsbbook.business.OrderValue;
import com.alsbbook.business.OrderResultValue;

public class Client {
	static int orderId = 1;
	static int numCalls = 5;
	
	public static void main(String[] args) {
		OrderValue order = null;
		OrderResultValue result = null;
		SyncBusinessService service = null;
		SyncBusinessPortType port = null;
		String url = "http://localhost:7001/sync/SyncBusinessService?WSDL";
		
		// Connect to the web service
		System.out.println("Connecting to the web service at " + url);
		System.out.println("This will take about 2.5 minutes to complete. Be patient!");
		Date connectStart = new Date();
		try {
			service = new SyncBusinessService_Impl(url);
			port = service.getSyncBusinessService();
		} catch(ServiceException ex) {
			System.out.println("ServiceException!");
			ex.printStackTrace();
		} 
		Date connectEnd = new Date();
		// Do the synchronous work
		for(int i = 0; i < numCalls; i++) {
			try {
				order = generateOrder();
				result = port.submitOrder(order);	
			} catch(RemoteException ex) {
				System.out.println("RemoteException!");
				ex.printStackTrace();
			}
			if(order == null || result == null) {
				System.out.println("ERROR: Either order or result was null!");
			}
		}
		Date syncWorkDone = new Date();
		
		// Print the summary of the timings
		System.out.println("\n\nSynchronous Timing Results");
		System.out.println("---------------------------");
		System.out.println("Time spent connecting to the service: " + (connectEnd.getTime() - connectStart.getTime()) + " ms.");
		System.out.println("Total time spent for " + numCalls + " service calls: " + (syncWorkDone.getTime() - connectEnd.getTime()) + " ms.");
		System.out.println("Average time per service call: " + ((syncWorkDone.getTime() - connectEnd.getTime())/numCalls) + " ms.");
	}
	
	private static OrderValue generateOrder() {
		OrderValue order = new OrderValue();
		order.setOrderId(orderId++);
		order.setOrderDate(Calendar.getInstance() );
		return order;
	}
}
