package proxy;
import proxy.TemperamentalCustomerBS;

public class LoadTestClient {
	private static final String customerUrl = "http://localhost:7001/esb/TemperamentalCustomer?WSDL";
	private static final String creditUrl = "http://localhost:7001/esb/TemperamentalCredit?WSDL";
	private static TCrBS creditPort = null;
	private static TCBS customerPort = null;
	
	public static void main(String[] args) {
		runMonitoringTest();
		// Uncomment the following line to run the
		// failover test in chapter 9
		//runServiceFailoverTest();
	}
	
	/**
	 * Perform the necessary housekeeping to connect to the 
	 * proxy services
	 */
	private static void loadServiceReferences() {
		try {
			System.out.println("Opening the credit service as " + creditUrl);
			TemperamentalCreditBS creditService = new TemperamentalCreditBS_Impl(creditUrl);
			creditPort = creditService.getTCrBSSoapPort();
			
			System.out.println("Opening the customer service as " + customerUrl);
			TemperamentalCustomerBS customerService = new TemperamentalCustomerBS_Impl(customerUrl);
			customerPort = customerService.getTCBSSoapPort();
		} catch(Exception ex) {
			ex.printStackTrace();
		}
	}
	
	private static void runMonitoringTest() {
		try {
			loadServiceReferences();
			System.out.println("Invoking the methods...");

			// Generate a warning on Op A
			creditPort.setDelay(2);
			creditPort.variableOpA("foo");
			
			// Generate a minor alert on Op B
			creditPort.setDelay(3);
			creditPort.variableOpB("foo");
			
			// Generate a major alert on Op C
			creditPort.setDelay(6);
			creditPort.variableOpC("foo");
			
			// Generates a fatal alert
			creditPort.setDelay(25);
			creditPort.variableCreditCheck("William Smith");
			
			// Generate a critical customer alert
			customerPort.setDelay(12);
			customerPort.getVariableCustomer(2);
			
			// Generate a fatal customer alert
			customerPort.setDelay(25);
			customerPort.getVariableCustomer(2);
		} catch(Exception ex) {
			ex.printStackTrace();
		}
	}
	
	private static void runServiceFailoverTest() {
		try {
			loadServiceReferences();
			//	Generate a critical customer alert
			creditPort.setDelay(60);
			String creditRating = creditPort.variableCreditCheck("timeout");
			System.out.println("Credit rating is: " + creditRating);
		} catch(Exception ex) {
			ex.printStackTrace();
		}
	}
}
