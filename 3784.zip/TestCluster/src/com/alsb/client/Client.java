package com.alsb.client;

import java.rmi.RemoteException;
import javax.xml.rpc.ServiceException;

public class Client {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String url = "http://localhost:7301/sbresource?PROXY/EchoService/Echo";
		String[] names = new String[] {"Foo", "Bar", "Baby", "Test", "Simple", "Arfy!" };
		try {
			for (int i = 0; i < names.length; i++) {
				EchoService_Service service = new EchoService_Service_Impl(url);
				EchoService_PortType port = service.getEchoServiceSOAP();
				String result = port.echo(names[i]);
				System.out.println("Received the string result: " + result);
			}
		} catch(ServiceException ex) {
			ex.printStackTrace();
		} catch(RemoteException ex) {
			ex.printStackTrace();
		}
	}
}
