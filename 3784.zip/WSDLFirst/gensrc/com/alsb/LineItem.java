/**
 * Generated from schema type t=LineItem@http://www.alsb.com
 */
package com.alsb;

public class LineItem implements java.io.Serializable {

  private com.alsb.Product product;

  public com.alsb.Product getProduct() {
    return this.product;
  }

  public void setProduct(com.alsb.Product product) {
    this.product = product;
  }

  private int quantity;

  public int getQuantity() {
    return this.quantity;
  }

  public void setQuantity(int quantity) {
    this.quantity = quantity;
  }

}
