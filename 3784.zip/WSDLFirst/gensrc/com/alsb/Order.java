/**
 * Generated from schema type t=Order@http://www.alsb.com
 */
package com.alsb;

public class Order implements java.io.Serializable {

  private java.lang.String firstName;

  public java.lang.String getFirstName() {
    return this.firstName;
  }

  public void setFirstName(java.lang.String firstName) {
    this.firstName = firstName;
  }

  private java.lang.String lastName;

  public java.lang.String getLastName() {
    return this.lastName;
  }

  public void setLastName(java.lang.String lastName) {
    this.lastName = lastName;
  }

  private com.alsb.LineItem[] lineItem;

  public com.alsb.LineItem[] getLineItem() {
    return this.lineItem;
  }

  public void setLineItem(com.alsb.LineItem[] lineItem) {
    this.lineItem = lineItem;
  }

}
