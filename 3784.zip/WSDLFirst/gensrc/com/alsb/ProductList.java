/**
 * Generated from schema type t=ProductList@http://www.alsb.com
 */
package com.alsb;

public class ProductList implements java.io.Serializable {

  private com.alsb.Product[] product;

  public com.alsb.Product[] getProduct() {
    return this.product;
  }

  public void setProduct(com.alsb.Product[] product) {
    this.product = product;
  }

}
