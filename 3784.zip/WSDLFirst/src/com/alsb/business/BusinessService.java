package com.alsb.business;

public class BusinessService {

}
